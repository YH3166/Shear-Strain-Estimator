function [SoilMotion,MaxStrain,Strain]=TransferFunction(par,FFTMotion,CompGModel,SampleRate)

%Extract parameters from par
H=par(:,1); %Thicknesses of each layer
V=par(:,2); %Velocities of each layer
P=par(:,3); %Densities in each layer
Damp=par(:,4); %Damping ratio in each layer
Gred=par(:,5); %Modulus Reduction in each layer

NumberofLayer =length(P);
NumberofSamps = length(FFTMotion);

%Check input motion is a row vector
[NumRows,NumCols]=size(FFTMotion);
if(NumCols<NumRows)
    FFTMotion=FFTMotion';
end

%Calculate frequencies to be processed
f=[0:(NumberofSamps/2)]./(NumberofSamps*SampleRate);
w=f.*2*pi;
FFT_f = [0:(NumberofSamps/2) -(NumberofSamps/2)+1:-1]./(NumberofSamps*SampleRate);
FFT_w = 2*pi*FFT_f;
NumberofF = length(f);

% computes G* from Gred based on the formula in Shake or Shake91
Gsec=Gred.*P.*(V.^2);
if strcmp(CompGModel,'Shake')
        Gcomplex= Gsec.*(1+2.*1i.*Damp); 
elseif strcmp(CompGModel,'Shake91')
        Gcomplex = Gsec.*((1-2.*Damp.^2)+2.*1i.*Damp.*sqrt(1-Damp.^2));
else
    error([CompGModel ' is an invalid input for CompGModel: for valid inputs see help'])
end

% computing the complex impedance, E and F, the outcropping to surface
% ratio A1N, and the outcropping displacement to strain ratio u2strain
% Initiate E and F by setting E1 and F1 to equal 1
TransferFunc = ones(NumberofLayer,NumberofF);
ImpedanceRatio = zeros(NumberofLayer,NumberofF);
Em = zeros(NumberofLayer,NumberofF);
Fm = zeros(NumberofLayer,NumberofF);
Em(1,:) = 1;
Fm(1,:) = 1;
A1N = zeros(1,NumberofF);
H_middle = H/2;
u2Strain = zeros(NumberofLayer,NumberofF);


for j = 1:NumberofF
k_star = sqrt(P./Gcomplex)*w(j);

for i = 1:NumberofLayer-1
    ImpedanceRatio(i,j) = sqrt(P(i)*Gcomplex(i)/P(i+1)/Gcomplex(i+1));
    Em(i+1,j) = 0.5*Em(i,j)*(1+ImpedanceRatio(i,j))*exp(1i*k_star(i)*H(i))+0.5*Fm(i,j)*(1-ImpedanceRatio(i,j))*exp(-1i*k_star(i)*H(i));
    Fm(i+1,j) = 0.5*Em(i,j)*(1-ImpedanceRatio(i,j))*exp(1i*k_star(i)*H(i))+0.5*Fm(i,j)*(1+ImpedanceRatio(i,j))*exp(-1i*k_star(i)*H(i));
end

A1N(j) = 1/Em(NumberofLayer,j);
TransferFunc(:,j) = (Em(:,j)+Fm(:,j))/2/Em(NumberofLayer,j);
u2Strain(:,j) = 1i*k_star.*(Em(:,j).*exp(1i*k_star.*H_middle)-Fm(:,j).*exp(-1i*k_star.*H_middle))/2/Em(NumberofLayer,j);
end

% flip the ratio to extend to the full FFT range and calcualte FFT strain
FFT_u_outcropping = FFTMotion.*(-1./FFT_w.^2)*9.81;
FFT_strain = zeros(NumberofLayer,NumberofSamps);
for i = 1:NumberofLayer
    u2Strain(i,NumberofF+1:NumberofSamps)=conj(fliplr(u2Strain(i,2:(NumberofSamps/2))));
    FFT_strain(i,:) = u2Strain(i,:).*FFT_u_outcropping;
end
FFT_strain(:,1) = 0;

R2S = A1N;
R2S(NumberofF+1:NumberofSamps)=conj(fliplr(A1N(2:(NumberofSamps/2))));

TF = zeros(NumberofLayer,NumberofSamps);
for i = 1:NumberofLayer
    TF(i,NumberofF+1:NumberofSamps)=conj(fliplr(TransferFunc(i,2:(NumberofSamps/2))));
    TF(i,1:NumberofF)=TransferFunc(i,1:NumberofF);
end

% calculate soil surface acceleration time history
FFT_acc_surface = R2S.*FFTMotion;
SoilMotion = real(ifft(FFT_acc_surface));

% calculate the strain time history for each layer
Strain = zeros(NumberofLayer,NumberofSamps);
MaxStrain = zeros(NumberofLayer,1);

for i = 1:NumberofLayer
    Strain(i,:) = real(ifft(FFT_strain(i,:)));
    MaxStrain(i) = max(abs(Strain(i,:)))*100;
end
end
