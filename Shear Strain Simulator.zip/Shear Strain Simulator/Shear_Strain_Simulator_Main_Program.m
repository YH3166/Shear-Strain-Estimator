clear;close;clc;
cd 'C:\Users\huyh1\Desktop\Shear Strain Simulator'
load SoilProfile.mat                                                % Layer number, thickness, SWV, density
load MaterialCurve.mat                                              % damping curve; stiffness reduction curve
load Bedrock_Motion.mat

T = [0.01:0.01:0.58 0.6:0.02:1 1.05:0.05:2.4 2.5:0.1:5.2 5.4:0.2:8 8.5:0.5:10]';   % period to compute response spectra
[~,Bedrock_RSV,~] = ResponseSpectra(Bedrock_Motion(:,1),Bedrock_Motion(:,2),T,0.05); % calculate the velocity response spectra
[simulated_strain,~] = Strain_simulator(Bedrock_RSV,SoilProfile,MaterialCurve,1);  % estimate shear strain using the proposed method
[SHAKEMaxStrain] = SHAKE(SoilProfile,MaterialCurve,Bedrock_Motion);          % SHAKE analysis (for validation)

% Validate estimated shear strain profile with results from SHAKE
H = SoilProfile(:,2);
h = zeros(length(H)-1,1);        % mid-layer depth (accumulated)
for i = 1:length(H)
    h(i) = sum(H(1:i))-H(i)/2;
end

hold on
p1 = plot(SHAKEMaxStrain,h,'r','LineWidth',2);
p2 = plot(simulated_strain,h,'k','LineWidth',2);
legend('SHAKE Result','This study')
ylabel('Depth (m)')
xlabel('Maximum Shear Strain (%)')
legend('Location','southeast')
set(gca,'Ydir','reverse');
hold off