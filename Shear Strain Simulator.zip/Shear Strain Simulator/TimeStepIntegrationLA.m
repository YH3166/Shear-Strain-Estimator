function displacement=TimeStepIntegrationLA(time,groundmotion,period,damping)

% t = time step
% w = natural frequency
% u = SDOF displacement vector

t=time(2)-time(1);
w=2*pi/period;

[groundmotion1,~]=size(groundmotion);

gamma=1/2;
beta=1/6;

b1=1/(beta*(t^2));
b2=gamma/(beta*t);
b3=1/(beta*t);
b4=gamma/beta-1;
b5=1/(2*beta)-1;
b6=t*gamma/(2*beta)-t;

displacement(1,1)=0;
velocity(1,1)=0;
acceleration(1,1)=-groundmotion(1,1)-2*damping*w*velocity(1,1)-(w^2)*displacement(1,1);

for i=2:groundmotion1
    displacement(i,1)=(-groundmotion(i,1)+(b1+2*b2*damping*w)*displacement(i-1,1)+(b3+2*b4*damping*w)*velocity(i-1,1)+(b5+2*b6*damping*w)*acceleration(i-1,1))/(b1+2*b2*damping*w+w^2);
    velocity(i,1)=b2*(displacement(i,1)-displacement(i-1,1))-b4*velocity(i-1,1)-b6*acceleration(i-1,1);
    acceleration(i,1)=b1*(displacement(i,1)-displacement(i-1,1))-b3*velocity(i-1,1)-b5*acceleration(i-1,1);
end

end