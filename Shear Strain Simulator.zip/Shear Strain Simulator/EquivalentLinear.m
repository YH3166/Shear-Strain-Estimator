function [success, SurfaceAcc,InputMotion,StrainHist,par,TransferFunc] = EquivalentLinear(SoilModel,inputm,SampleRate,MaterialCurve,IterationPar,PaddingSwitch)

% do some initialisation of outputs
success = 1; % this will be over-written to 0 and returned to the calling function if the convergence fails
SurfaceAcc=[];
InputMotion=[];
StrainHist=[];
par=[];
TransferFunc=[];

% Calculate Fourier Transform of input motion
NumSamps=2^nextpow2(length(inputm)+1);  %Resize input motion to be a factor of 2 and calculate fourier transform
Motion=zeros(1,NumSamps);
Motion(2:length(inputm)+1)=inputm;
FFTMotion=fft(Motion);

%Define variable par which will store the soil model in a format suitable for use with TransferFunction
[NumLayers,~]=size(SoilModel);
par=zeros(NumLayers,7);
par(:,1:3)=SoilModel(:,1:3);    %copy thicknesses, velocities and densities
par(:,6:7)=SoilModel(:,4:5);    %re-assign modulus and damping pointers to point to associated strain column in ModCurv and DampCurv respectively

%Set initial modulus reduction and damping values for each layer to be the low strain values from the respective 
% modulus and damping curves for each layer.
for m=1:NumLayers
    par(m,4)=MaterialCurve{par(m,6),1}(1,2);
    par(m,5)=MaterialCurve{par(m,7),2}(1,2);
end

% Defining the default iteration parameters
if nargin < 5
      strainratio =0.65;
      tolerance = 5;            % percentage error tolerance
      niter = 100;                % maximum number of iterations to be used when determining equivalent linear parameters
  else
    strainratio = IterationPar(1)/100;
    tolerance = IterationPar(2);
    niter = IterationPar(3);
end

effstrain=zeros(NumLayers,1);

for s=1:niter
    OldDampMod=par(:,4:5);
    tempstrain=effstrain;
    par(:,4)=par(:,4)./100; %Convert damping in each layer from percentage to fraction
    [PaddedSurfaceAcc,MaxStrain,StrainHist]=TransferFunction(par,FFTMotion,'Shake91',SampleRate);
    
    % Computing the effective strain ratio in log10 space
    effstrain=log10(strainratio.*MaxStrain);
    for m=1:NumLayers 
        % calculating the equivalent linear Gred from the modulus reduction curve using linear interpolation.
        indmod = find(MaterialCurve{par(m,7),2}(:,1)>effstrain(m));
        if isempty(indmod)
            disp(m)
            disp(effstrain(m))
            disp(MaterialCurve{par(m,7),2})
            disp(s)
            success = 0;
            return
        elseif indmod(1)==1
            disp(['Have not moved from first strain for layer ' num2str(m) ' modulus'])
            success = 0;
            return
        else
            dist=MaterialCurve{par(m,7),2}(indmod(1),1)-effstrain(m);
            slope = (MaterialCurve{par(m,7),2}(indmod(1),2)-MaterialCurve{par(m,7),2}(indmod(1)-1,2))/(MaterialCurve{par(m,7),2}(indmod(1),1)-MaterialCurve{par(m,7),2}(indmod(1)-1,1));
            par(m,5) = MaterialCurve{par(m,7),2}(indmod(1),2)-dist*slope;
        end
        % calculating the equivalent linear damping ratio from the damping curve using linear interpolation
        inddamp = find(MaterialCurve{par(m,6),1}(:,1)>effstrain(m));
        if isempty(indmod)
            success = 0;
            return
        elseif inddamp(1)==1
            disp(['Have not moved from first strain for layer ' num2str(m) ' damping'])
            success = 0;
            return
        else
            %par(m,4)=par(m,4).*100;             %convert damping back to a percentage  % DR 2 July - Not Required
            dist=MaterialCurve{par(m,6),1}(inddamp(1),1)-effstrain(m);
            slope = (MaterialCurve{par(m,6),1}(inddamp(1),2)-MaterialCurve{par(m,6),1}(inddamp(1)-1,2))/(MaterialCurve{par(m,6),1}(inddamp(1),1)-MaterialCurve{par(m,6),1}(inddamp(1)-1,1));
            par(m,4) = MaterialCurve{par(m,6),1}(inddamp(1),2)-dist*slope;   
        end
    end

    %test the difference between the old parameters and the new ones
    percentagediff=[abs((OldDampMod-par(:,4:5))./par(:,4:5)*100) abs((OldDampMod-par(:,4:5))./OldDampMod*100)];
    test = find(max(percentagediff) > tolerance);
    if isempty(test)
        disp(['Equivalent Linear convergence succesful in ' num2str(s) ' iterations'])
        disp(['percentage error = ',num2str(max(percentagediff))]) 
          break
    elseif s == niter
        disp('failed to converge')
        disp(['percentage error = ',num2str(max(percentagediff))]) 
    end
end

% Re-assign the damping and Gred values in each layer to the values at the penultimate iteration. 
par(:,4:5) = OldDampMod;

% Removing the effects of padding if desired
if ((nargin > 6) && (PaddingSwitch == 'Pad'))
    SurfaceAcc=PaddedSurfaceAcc;
    InputMotion=Motion;
else
    InputMotion=Motion(2:length(inputm)+1);
    SurfaceAcc=PaddedSurfaceAcc(2:length(inputm)+1);
end
end