
function [RSA,RSV,RSD] = ResponseSpectra(t,Acc,T,damping)                % Acc in g; damping in integer
[L1,L2] = size(Acc);
[L3,L4] = size(t);
x = length(T);

if L2>L1
    Acc = Acc';
end
if L4>L3
    t = t';
end
L = max(L1,L2);

u = zeros(L,x);
for j = 1:x
    u(:,j)=TimeStepIntegrationLA(t,Acc,T(j),damping);
end
rsa = zeros(1,x);
rsd = zeros(1,x);

for j=1:x
    rsd(1,j)=max(abs(u(:,j)));
    if rsd(1,j) == inf
        rsd(1,j) = 0;
    end
    rsa(1,j)=rsd(1,j)*((2*pi/T(j))^2);
end
RSA = rsa';                                                             % unit in g
RSV = RSA.*T/2/pi*9800;                                                 % unit in mm/s
RSD = RSV.*T/2/pi;                                                      % unit in mm
end