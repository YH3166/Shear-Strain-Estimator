function [simulated_strain,period_shift_ratio] = Strain_simulator(Bedrock_RSV,SoilProfile,MaterialCurve,converenge_rate)
[~,N2] = size(Bedrock_RSV);
if N2 == 2
    T = Bedrock_RSV(:,1);
    Bedrock_RSV = Bedrock_RSV(:,2);
else
    T = [0.01:0.01:0.58 0.6:0.02:1 1.05:0.05:2.4 2.5:0.1:5.2 5.4:0.2:8 8.5:0.5:10]';
end
H = SoilProfile(:,2);
V = SoilProfile(:,3);
P = SoilProfile(:,4);
Vr = SoilProfile(end,3);
Pr = SoilProfile(end,4);
N = length(H);

Vs = sum(H)./sum(H./V);
Ps = sum(H.*P)/sum(H);
impedance = Vs*Ps/Vr/Pr;
damping_e = 5;
Tj = zeros(1,3);
Tj(1) = 4*sum(H./V);
Tj(2) = Tj(1)/3;
Tj(3) = Tj(1)/5;

Gred = ones(N,1);
damping = ones(N,1);
theta = zeros(N,3);
Tm = zeros(N,1);
Vd = V;
simulated_strain = zeros(N,1);
simulated_strain_mode = zeros(N,3);


% iteration
max_error = zeros(100,1);
for k = 1:100
for i = 1:N-1
    Tm(i) = 4*(sum(H(1:i)./Vd(1:i))-H(i)/Vd(i)/2);
end
Tm(end) = 4*sum(H(1:i)./Vd(1:i));

RSV = zeros(3,1);
for j = 1:3
    RSV(j) = interp1(T,Bedrock_RSV,Tj(j));
    simulated_strain_mode(end,j) = sqrt(7/(damping_e+2))*impedance/Vr*4/pi/(2*j-1)*RSV(j)/10;      % maximum bedrock shear in percentage
    for i = 1:N
        theta(i,j) = pi/2*Tm(i)/Tm(end)*(2*j-1);
    end
end

for j = 1:3
    for i = 1:N-1
        simulated_strain_mode(N-i,j) = simulated_strain_mode(N-i+1,j)*P(N-i+1)/P(N-i)*(Vd(N-i+1)/Vd(N-i))^2*min(1,abs(sin(theta(N-i,j))-theta(N-i,j)/cos(theta(N-i,j))*damping(N-i)^2/10000))/min(abs(sin(theta(N-i+1,j))-theta(N-i+1,j)/cos(theta(N-i+1,j))*damping(N-i+1)^2/10000),1);
    end
end

old_Gred = Gred;
old_damping = damping;

for i = 1:N
    simulated_strain(i) = sqrt(simulated_strain_mode(i,1)^2+simulated_strain_mode(i,2)^2+simulated_strain_mode(i,3)^2);
    Gred(i) = interp1(MaterialCurve{i,2}(:,1),MaterialCurve{i,2}(:,2),log10(0.65*simulated_strain(i)));
    damping(i) = interp1(MaterialCurve{i,1}(:,1),MaterialCurve{i,1}(:,2),log10(0.65*simulated_strain(i)));
    Vd(i) = V(i)*sqrt(Gred(i));
end
damping_e = sum(damping.*H.*P.*Vd.^2.*simulated_strain.^2)/sum(H.*P.*Vd.^2.*simulated_strain.^2);

Vs = sum(H)./sum(H./Vd);
Vr = Vd(end);

impedance = Vs*Ps/Vr/Pr;
Tj = zeros(1,3);
Tj(1) = 4*sum(H./Vd);
Tj(2) = Tj(1)/3;
Tj(3) = Tj(1)/5;

error_Gred = abs(old_Gred-Gred)./old_Gred*100;
error_damping = abs(old_damping-damping)./old_damping*100;

max_error(k) = max(max(error_Gred),max(error_damping));

if max_error(k)<converenge_rate
    Iteration_Num = sprintf('Iteration completed in %d circles',k);
    disp(Iteration_Num)
    break
end
end


% if converenge cannot be reached, its likely that the intensity has 
% exceeded the level to maintain stablility. 
if isnan(damping_e)
H = SoilProfile(:,2);
V = SoilProfile(:,3);
P = SoilProfile(:,4);
Vr = SoilProfile(end,3);
Pr = SoilProfile(end,4);
N = length(H);

Vs = sum(H)./sum(H./V);
Ps = sum(H.*P)/sum(H);
impedance = Vs*Ps/Vr/Pr;
damping_e = 5;
Tj = zeros(1,3);
Tj(1) = 4*sum(H./V);
Tj(2) = Tj(1)/3;
Tj(3) = Tj(1)/5;

Gred = ones(N,1);
damping = ones(N,1);
theta = zeros(N,3);
Tm = zeros(N,1);
Vd = V;
simulated_strain = zeros(N,1);
simulated_strain_mode = zeros(N,3);


% iteration
for k = 1:3
for i = 1:N-1
    Tm(i) = 4*(sum(H(1:i)./Vd(1:i))-H(i)/Vd(i)/2);
end
Tm(end) = 4*sum(H(1:i)./Vd(1:i));

for j = 1:3
    RSV = min(interp1(T,Bedrock_RSV,Tj(j)*[0.9:0.01:1.5]));
    simulated_strain_mode(end,j) = sqrt(7/(damping_e+2))*impedance/Vr*4/pi/(2*j-1)*RSV/10/1.25;      % maximum bedrock shear in percentage
    for i = 1:N
        theta(i,j) = pi/2*Tm(i)/Tm(end)*(2*j-1);
    end
end


for j = 1:3
    for i = 1:N-1
        simulated_strain_mode(N-i,j) = simulated_strain_mode(N-i+1,j)*P(N-i+1)/P(N-i)*(Vd(N-i+1)/Vd(N-i))^2*min(1,abs(sin(theta(N-i,j))-theta(N-i,j)/cos(theta(N-i,j))*damping(N-i)^2/10000))/min(abs(sin(theta(N-i+1,j))-theta(N-i+1,j)/cos(theta(N-i+1,j))*damping(N-i+1)^2/10000),1);
    end
end

for i = 1:N
    simulated_strain(i) = sqrt(simulated_strain_mode(i,1)^2+simulated_strain_mode(i,2)^2+simulated_strain_mode(i,3)^2);
    Gred(i) = interp1(MaterialCurve{i,2}(:,1),MaterialCurve{i,2}(:,2),log10(0.65*simulated_strain(i)));
    damping(i) = interp1(MaterialCurve{i,1}(:,1),MaterialCurve{i,1}(:,2),log10(0.65*simulated_strain(i)));
    Vd(i) = V(i)*sqrt(Gred(i));
end
damping_e = sum(damping.*H.*P.*Vd.^2.*simulated_strain.^2)/sum(H.*P.*Vd.*simulated_strain.^2);

Vs = sum(H)./sum(H./Vd);
Vr = Vd(end);

impedance = Vs*Ps/Vr/Pr;
Tj = zeros(1,3);
Tj(1) = 4*sum(H./Vd);
Tj(2) = Tj(1)/3;
Tj(3) = Tj(1)/5;

end
Iteration_Num = sprintf('Convergence not completed, strain output after 3 cycles');
disp(Iteration_Num)
end

period_shift_ratio = Tj(1)/(4*sum(H./V));
end