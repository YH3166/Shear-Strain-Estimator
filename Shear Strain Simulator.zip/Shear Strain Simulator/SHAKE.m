function [LayerMaxStrain] = SHAKE(SoilProfile,MaterialCurve,Motion_TH)                               
[NumLayers,~]=size(SoilProfile); 
SoilModel = zeros(NumLayers,5); 
SoilModel(:,1) = SoilProfile(:,2); 
SoilModel(:,2) = SoilProfile(:,3); 
SoilModel(:,3) = SoilProfile(:,4)/1000; 
SoilModel(:,4) = SoilProfile(:,1); 
SoilModel(:,5) = SoilProfile(:,1); 
inputmAcc = Motion_TH;
SampleRate = inputmAcc(2,1)-inputmAcc(1,1); 
inputm = inputmAcc(:,2);
IterationPar = [(6.5-1)*10,1,100]; 
[~,~,~,StrainHist,~,~] = EquivalentLinear(SoilModel,inputm,SampleRate,MaterialCurve,IterationPar,'Pad');
LayerMaxStrain = max(abs(StrainHist),[],2)*100;
end